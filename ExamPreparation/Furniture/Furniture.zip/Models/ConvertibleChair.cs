﻿using FurnitureManufacturer.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FurnitureManufacturer.Models
{
   public class ConvertibleChair : Chair, IChair,IConvertibleChair
    {
        private bool isConverted=false;

        public ConvertibleChair(string model, string materialType, decimal price, decimal height, int numberOfLegs) : base(model, materialType, price, height, numberOfLegs)
        {
        }

        public bool IsConverted
        {
            get
            {
                return this.isConverted;
            }
        }

        public new decimal Height
        {
            get { return this.Height; }
           private set { }
        }
          
        public void Convert()
        {
            this.Height=0.1m;
        }
    }
}
