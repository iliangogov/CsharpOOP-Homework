﻿using FurnitureManufacturer.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FurnitureManufacturer.Models
{
    public class Table :Furniture, ITable
    {
        private decimal lenght;
        private decimal width;
        private decimal area;

        public Table(string model, string materialType, decimal price, decimal height,decimal length,decimal width) : base(model, materialType, price, height)
        {
            this.lenght = length;
            this.width = width;
        }

        public decimal Area
        {
            get
            {
                this.area= this.lenght * this.width;
                return this.area;
            }
        }

        public decimal Length
        {
            get
            {
                return this.lenght;
            }
        }

        public decimal Width
        {
            get
            {
                return this.width;
            }
        }
    }
}
